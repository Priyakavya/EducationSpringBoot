-- ============================================================================
--  EDUCATION MANAGEMENT SYSTEM - SCHEMA (MySQL 8.x)
--  Run first:  mysql -u root -p < 01_schema.sql
--
--  Table order matters: a child table cannot reference a parent that does not
--  exist yet, so parents (students, teachers) come before children.
-- ============================================================================

DROP DATABASE IF EXISTS education_db;
CREATE DATABASE education_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE education_db;

-- ---------------------------------------------------------------------------
-- 1. STUDENTS  (no foreign keys - a root table)
-- ---------------------------------------------------------------------------
CREATE TABLE students (
    id              BIGINT       NOT NULL AUTO_INCREMENT,
    name            VARCHAR(100) NOT NULL,
    email           VARCHAR(150) NOT NULL,
    enrollment_date DATE         NOT NULL,

    PRIMARY KEY (id),
    CONSTRAINT uk_students_email UNIQUE (email),
    INDEX idx_students_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- 2. TEACHERS  (also a root table)
-- ---------------------------------------------------------------------------
CREATE TABLE teachers (
    id         BIGINT       NOT NULL AUTO_INCREMENT,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL,
    department VARCHAR(100) NOT NULL,

    PRIMARY KEY (id),
    CONSTRAINT uk_teachers_email UNIQUE (email),
    INDEX idx_teachers_department (department)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- 3. COURSES  ->  teachers      (One-to-Many: one teacher, many courses)
--
--  ON DELETE RESTRICT: MySQL refuses to delete a teacher who still owns
--  courses. The API returns 409 before it ever reaches this point, but the
--  constraint is the real guarantee - it also protects direct SQL access.
-- ---------------------------------------------------------------------------
CREATE TABLE courses (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    title       VARCHAR(150) NOT NULL,
    description TEXT         NULL,
    teacher_id  BIGINT       NOT NULL,

    PRIMARY KEY (id),
    CONSTRAINT fk_courses_teacher
        FOREIGN KEY (teacher_id) REFERENCES teachers (id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    INDEX idx_courses_teacher (teacher_id),
    INDEX idx_courses_title (title)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- 4. ENROLLMENTS  ->  students + courses
--
--  This is the junction table that resolves the Many-to-Many between students
--  and courses. It is NOT a pure junction table: it carries enrollment_date,
--  and grades reference it, which is why it has its own surrogate id.
--
--  uk_enrollments_student_course is the rule "a student cannot enrol twice in
--  the same course", enforced by the database itself. Two concurrent POSTs
--  cannot both pass the service-layer check and both insert.
--
--  ON DELETE CASCADE: removing a student or a course removes their enrolments.
-- ---------------------------------------------------------------------------
CREATE TABLE enrollments (
    id              BIGINT NOT NULL AUTO_INCREMENT,
    student_id      BIGINT NOT NULL,
    course_id       BIGINT NOT NULL,
    enrollment_date DATE   NOT NULL,

    PRIMARY KEY (id),
    CONSTRAINT fk_enrollments_student
        FOREIGN KEY (student_id) REFERENCES students (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_course
        FOREIGN KEY (course_id) REFERENCES courses (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT uk_enrollments_student_course UNIQUE (student_id, course_id),
    INDEX idx_enrollments_student (student_id),
    INDEX idx_enrollments_course (course_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- 5. EXAMS  ->  courses         (One-to-Many: one course, many exams)
-- ---------------------------------------------------------------------------
CREATE TABLE exams (
    id        BIGINT       NOT NULL AUTO_INCREMENT,
    course_id BIGINT       NOT NULL,
    exam_date DATE         NOT NULL,
    title     VARCHAR(150) NOT NULL,

    PRIMARY KEY (id),
    CONSTRAINT fk_exams_course
        FOREIGN KEY (course_id) REFERENCES courses (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_exams_course (course_id),
    INDEX idx_exams_date (exam_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- 6. GRADES  ->  enrollments + exams
--
--  score is DECIMAL(5,2), never FLOAT/DOUBLE. Binary floating point cannot
--  represent 0.1 exactly, so marks would drift on aggregation.
--  5,2 = up to 999.99; the API caps the value at 100 via @DecimalMax.
--
--  CHECK constraint (MySQL 8.0.16+) is a second line of defence behind the
--  bean validation in GradeRequest.
-- ---------------------------------------------------------------------------
CREATE TABLE grades (
    id            BIGINT       NOT NULL AUTO_INCREMENT,
    enrollment_id BIGINT       NOT NULL,
    exam_id       BIGINT       NOT NULL,
    score         DECIMAL(5,2) NOT NULL,

    PRIMARY KEY (id),
    CONSTRAINT fk_grades_enrollment
        FOREIGN KEY (enrollment_id) REFERENCES enrollments (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_grades_exam
        FOREIGN KEY (exam_id) REFERENCES exams (id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT uk_grades_enrollment_exam UNIQUE (enrollment_id, exam_id),
    CONSTRAINT chk_grades_score CHECK (score >= 0 AND score <= 100),
    INDEX idx_grades_enrollment (enrollment_id),
    INDEX idx_grades_exam (exam_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
--  Verify
-- ---------------------------------------------------------------------------
SHOW TABLES;

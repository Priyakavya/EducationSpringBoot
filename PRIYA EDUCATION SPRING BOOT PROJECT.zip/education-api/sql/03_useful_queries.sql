-- ============================================================================
--  REPORTING QUERIES
--  These are the queries behind the API's derived endpoints, plus the ones
--  you are most likely to be asked to write in a viva or interview.
-- ============================================================================

USE education_db;

-- ---------------------------------------------------------------------------
-- 1. Class roster: every student in one course
--    Backs GET /api/courses/{id}/students
-- ---------------------------------------------------------------------------
SELECT s.id, s.name, s.email, e.enrollment_date
FROM students s
JOIN enrollments e ON e.student_id = s.id
WHERE e.course_id = 1
ORDER BY s.name;

-- ---------------------------------------------------------------------------
-- 2. Full marks sheet - the four-table join at the heart of the schema
-- ---------------------------------------------------------------------------
SELECT
    s.name        AS student_name,
    c.title       AS course_title,
    ex.title      AS exam_title,
    ex.exam_date,
    g.score,
    CASE
        WHEN g.score >= 90 THEN 'A'
        WHEN g.score >= 80 THEN 'B'
        WHEN g.score >= 70 THEN 'C'
        WHEN g.score >= 60 THEN 'D'
        WHEN g.score >= 50 THEN 'E'
        ELSE 'F'
    END           AS letter_grade
FROM grades g
JOIN enrollments e ON e.id = g.enrollment_id
JOIN students    s ON s.id = e.student_id
JOIN courses     c ON c.id = e.course_id
JOIN exams      ex ON ex.id = g.exam_id
ORDER BY s.name, ex.exam_date;

-- ---------------------------------------------------------------------------
-- 3. Class average per exam
--    Backs GET /api/grades/exam/{examId}/average
-- ---------------------------------------------------------------------------
SELECT
    ex.id                       AS exam_id,
    ex.title                    AS exam_title,
    c.title                     AS course_title,
    COUNT(g.id)                 AS students_graded,
    ROUND(AVG(g.score), 2)      AS average_score,
    MAX(g.score)                AS highest,
    MIN(g.score)                AS lowest
FROM exams ex
JOIN courses c   ON c.id = ex.course_id
LEFT JOIN grades g ON g.exam_id = ex.id   -- LEFT JOIN so ungraded exams still appear
GROUP BY ex.id, ex.title, c.title
ORDER BY average_score DESC;

-- ---------------------------------------------------------------------------
-- 4. Teacher workload
-- ---------------------------------------------------------------------------
SELECT
    t.name                            AS teacher_name,
    t.department,
    COUNT(DISTINCT c.id)              AS courses_taught,
    COUNT(DISTINCT e.student_id)      AS distinct_students
FROM teachers t
LEFT JOIN courses c     ON c.teacher_id = t.id
LEFT JOIN enrollments e ON e.course_id = c.id
GROUP BY t.id, t.name, t.department
ORDER BY distinct_students DESC;

-- ---------------------------------------------------------------------------
-- 5. Each student's overall average, best and worst subject
-- ---------------------------------------------------------------------------
SELECT
    s.name,
    COUNT(g.id)              AS exams_taken,
    ROUND(AVG(g.score), 2)   AS overall_average
FROM students s
JOIN enrollments e ON e.student_id = s.id
JOIN grades g      ON g.enrollment_id = e.id
GROUP BY s.id, s.name
HAVING COUNT(g.id) > 0        -- HAVING filters AFTER grouping; WHERE cannot see AVG
ORDER BY overall_average DESC;

-- ---------------------------------------------------------------------------
-- 6. Students who have enrolled but have NO grades yet
--    Classic LEFT JOIN ... IS NULL "anti-join" pattern.
-- ---------------------------------------------------------------------------
SELECT DISTINCT s.id, s.name, s.email
FROM students s
JOIN enrollments e ON e.student_id = s.id
LEFT JOIN grades g ON g.enrollment_id = e.id
WHERE g.id IS NULL;

-- ---------------------------------------------------------------------------
-- 7. Course popularity, including courses nobody has taken
-- ---------------------------------------------------------------------------
SELECT
    c.title,
    t.name              AS taught_by,
    COUNT(e.id)         AS enrolled_count
FROM courses c
JOIN teachers t     ON t.id = c.teacher_id
LEFT JOIN enrollments e ON e.course_id = c.id
GROUP BY c.id, c.title, t.name
ORDER BY enrolled_count DESC;

-- ---------------------------------------------------------------------------
-- 8. Ranking with a window function (MySQL 8+)
--    Rank students within each exam.
-- ---------------------------------------------------------------------------
SELECT
    ex.title      AS exam_title,
    s.name        AS student_name,
    g.score,
    RANK() OVER (PARTITION BY ex.id ORDER BY g.score DESC) AS rank_in_exam
FROM grades g
JOIN exams ex      ON ex.id = g.exam_id
JOIN enrollments e ON e.id = g.enrollment_id
JOIN students s    ON s.id = e.student_id
ORDER BY ex.title, rank_in_exam;

-- ---------------------------------------------------------------------------
-- 9. Students scoring above the average for their exam (correlated subquery)
-- ---------------------------------------------------------------------------
SELECT s.name, ex.title AS exam_title, g.score
FROM grades g
JOIN exams ex      ON ex.id = g.exam_id
JOIN enrollments e ON e.id = g.enrollment_id
JOIN students s    ON s.id = e.student_id
WHERE g.score > (
    SELECT AVG(g2.score)
    FROM grades g2
    WHERE g2.exam_id = g.exam_id     -- correlated: re-evaluated per outer row
)
ORDER BY ex.title, g.score DESC;

-- ---------------------------------------------------------------------------
-- 10. Upcoming exams in the next 30 days
-- ---------------------------------------------------------------------------
SELECT ex.title, ex.exam_date, c.title AS course_title, t.name AS teacher_name
FROM exams ex
JOIN courses c  ON c.id = ex.course_id
JOIN teachers t ON t.id = c.teacher_id
WHERE ex.exam_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
ORDER BY ex.exam_date;

-- ---------------------------------------------------------------------------
-- 11. Data integrity audit - grades whose exam does not match the enrolled
--     course. The API blocks this, but run it after any bulk import.
--     A healthy database returns zero rows.
-- ---------------------------------------------------------------------------
SELECT g.id AS bad_grade_id, e.course_id AS enrolled_course, ex.course_id AS exam_course
FROM grades g
JOIN enrollments e ON e.id = g.enrollment_id
JOIN exams ex      ON ex.id = g.exam_id
WHERE e.course_id <> ex.course_id;

-- ---------------------------------------------------------------------------
-- 12. Pass/fail split per course (pass mark = 50)
-- ---------------------------------------------------------------------------
SELECT
    c.title,
    SUM(CASE WHEN g.score >= 50 THEN 1 ELSE 0 END) AS passed,
    SUM(CASE WHEN g.score <  50 THEN 1 ELSE 0 END) AS failed,
    ROUND(100.0 * SUM(CASE WHEN g.score >= 50 THEN 1 ELSE 0 END) / COUNT(g.id), 1) AS pass_pct
FROM grades g
JOIN enrollments e ON e.id = g.enrollment_id
JOIN courses c     ON c.id = e.course_id
GROUP BY c.id, c.title;

-- ---------------------------------------------------------------------------
-- 13. Check what indexes exist / read a query plan
-- ---------------------------------------------------------------------------
SHOW INDEX FROM enrollments;
EXPLAIN SELECT * FROM enrollments WHERE student_id = 1 AND course_id = 1;
